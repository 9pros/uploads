INSERT INTO `searchengines` (`domain`, `url`, `cookie_send`, `no_of_results_page`, `start`, `start_offset`, `max_results`, `regex`, `from_pattern`, `to_pattern`, `url_index`, `title_index`, `description_index`, `encoding`, `status`) VALUES
('www.baidu.com', 'http://www.baidu.com/s?wd=[--keyword--]&pn=[--start--]&tn=baiduadv&rn=[--num--]', '', 50, 0, 50, 50, '<div.*?c-container.*?>.*?<a.*?>(.*?)<\\/a>.*?f13.*?<a.*?>(.*?)<\\/a><div.*?<\\/div><\\/div>', NULL, NULL, 2, 1, 3, 'GBK', 1);

